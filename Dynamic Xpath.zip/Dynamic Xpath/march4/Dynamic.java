package march4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Dynamic {
	public void testRedif() {

		ChromeDriver driver = new ChromeDriver();
		driver.get("https://register.rediff.com/register/register.php?FormName=user_details");

		WebElement textCreateAccount = driver.findElement(By.xpath("//h2[text()='Create a Rediffmail account']"));
		System.out.println(textCreateAccount.getText());

		WebElement textAllFields = driver.findElement(By.xpath("//span[starts-with(text(),'All fields are mandatory.')]"));
		System.out.println(textAllFields.getText());

		WebElement textAllFields2 = driver.findElement(By.xpath("//span[contains(text(),'All fields')]"));
		System.out.println(textAllFields2.getText());

		WebElement textFullName = driver.findElement(By.xpath("//input[starts-with(@placeholder,'Enter your full name')]"));
		textFullName.sendKeys("Sakshi");

		WebElement textMail = driver.findElement(By.xpath("//input[contains(@placeholder,'Enter Rediffmail ID')]"));
		textMail.sendKeys("Sakshi123@gmail.com");

		WebElement textPassword = driver.findElement(By.xpath("//input[@type='password'and @placeholder='Enter password']"));
		textPassword.sendKeys("sakshi456@.");

		WebElement textReType = driver.findElement(By.xpath("//input[@id='newpasswd1'or @placeholder='Retype password']"));
		textReType.sendKeys("sakshi456@.");
		
		

	}
}
