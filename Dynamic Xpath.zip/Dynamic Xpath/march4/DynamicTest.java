package march4;

public class DynamicTest {
	public static void main(String[] args) {
		
		Dynamic d =new Dynamic();
		d.testRedif();
		
	}

}
