package march17;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Navigation;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class NavigateDemo {
	@Test
	public void testNavigate() throws InterruptedException
	{
		WebDriver driver=new ChromeDriver();
		Navigation nvn=driver.navigate();
		nvn.to("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		driver.findElement(By.linkText("WebTable")).click();
		
		Thread.sleep(3000);
		nvn.back();
		
		Thread.sleep(3000);
		nvn.forward();
		
		Thread.sleep(3000);
		nvn.refresh();

}
}