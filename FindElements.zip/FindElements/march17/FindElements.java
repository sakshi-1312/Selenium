package march17;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;


public class FindElements {
	@Test
	void TestLink() throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		
		driver.manage().window().maximize();
		
		Thread.sleep(5000);
		List<WebElement>allfooterLinks=driver.findElements(By.xpath("//*[@id=\"slot-list-container\"]/div/footer/div/div[3]/div[1]/div[2]/a[1]"));
		
		for(WebElement links : allfooterLinks) {
			System.out.println(links.getText());
			
			links.click();
			
			String allTitles=driver.getCurrentUrl();
			
			if(allTitles.contains("myntra") || allTitles.contains("Shopsy"))
			{
				Assert.assertTrue(true);
			}
		}
	
	}
	
	
	@Test(enabled=false)
	public void checkboxes() {
	WebDriver driver=new ChromeDriver();
	
	driver.get("https://demo.automationtesting.in/Register.html");
	
	driver.manage().window().maximize();
	
	List<WebElement> AllCheck=driver.findElements(By.xpath("//input[@type='checkbox']"));
	
	for(WebElement check : AllCheck) {
		//check.click();
		
		if(check.getDomAttribute("value").equals("Cricket") || check.getDomAttribute("value").equals("Hockey") ) {
			check.click();
		}
	}

}
}
