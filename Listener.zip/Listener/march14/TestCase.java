package march14;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(MyListner.class)
public class TestCase {
	@Test
public void login() {
	Assert.assertEquals(4, 4);
}
}
