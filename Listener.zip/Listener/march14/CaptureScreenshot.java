package march14;

import java.io.File;
import java.io.IOException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.Test;

public class CaptureScreenshot {
	@Test
	public void capture() throws IOException 
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		
		TakesScreenshot tks=(TakesScreenshot)driver; //typecasting
	   File source= tks.getScreenshotAs(OutputType.FILE);
		
	   File target=new File("D:\\Testing Batch 280\\MavenTestng\\target\\capture.png");
		
		FileHandler.copy(source, target);		
	}

}
