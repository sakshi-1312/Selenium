package march14;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class MyListner implements ITestListener{

	@Override
	public void onTestStart(ITestResult result) {
		System.out.println("Test case exicution started"+result.getName());
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("Test case Pass"+result.getName());
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("Test case Failed"+result.getName());
			}

	@Override
	public void onTestSkipped(ITestResult result) {
		System.out.println("Test case skipped"+result.getName());
			}


	@Override
	public void onFinish(ITestContext context) {
		System.out.println("All the test case exicution completed");
	}

}
