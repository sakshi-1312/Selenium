package march2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class XpathTest {
	public void AbsoluteXpath(){
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://javabykiran.in/other/CC/search");
		
		WebElement txtKeywords=driver.findElement(By.xpath("/html/body/div/div/div[5]/div[1]/form/div/div/input"));
		txtKeywords.sendKeys("Sakshi");
		
		WebElement txtPrizeRange=driver.findElement(By.xpath("/html/body/div/div/div[5]/div/form/div[3]/div/input"));
		txtPrizeRange.sendKeys("4000");
		
		WebElement txtTo=driver.findElement(By.xpath("/html/body/div/div/div[5]/div/form/div[3]/div[3]/input"));
		txtTo.sendKeys("6000");
		
		WebElement checkItemInStock=driver.findElement(By.xpath("//input[@id='in_stock']"));
		checkItemInStock.click();
		
		WebElement featuredProducts=driver.findElement(By.xpath("//input[@id='featured_only']"));
		featuredProducts.click();
		
		WebElement btnSearch=driver.findElement(By.xpath("//input[@value='Search']"));
		btnSearch.click();
		
	}

}
