package march2;

public class TestAbsolute {

	public static void main(String[] args) {
		XpathTest xt=new XpathTest(); 
		xt.AbsoluteXpath();

	}

}
