package march21;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

@Test
public class ImplicitDemo {
	public void testImplicit() throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/dynamic_loading/2");
		driver.findElement(By.xpath("//*[@id='start']/button")).click();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		//Thread.sleep(15000);
		//System.out.println(driver.findElement(By.xpath("//*[@id=\'finish\']/h4")).getText());
		
		//WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		
		//String text=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\\'finish\\']/h4"))).getText();
		//System.out.println(text);
		
		Wait<WebDriver>wait=new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(15))
				.pollingEvery(Duration.ofSeconds(3))
				.ignoring(NoSuchElementException.class);
		
	}

}
