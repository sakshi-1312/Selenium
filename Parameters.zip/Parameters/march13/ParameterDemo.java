package march13;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ParameterDemo {
WebDriver driver;
	
@Parameters({"browser","url"})
	@BeforeMethod
public void setUp(String brName,String URL) throws InterruptedException 
{
	if(brName.equalsIgnoreCase("chrome"))
	{
	driver=new ChromeDriver();
	}else if(brName.equalsIgnoreCase("firefox"))
	{
		driver=new FirefoxDriver();
	}else if(brName.equalsIgnoreCase("IE")) 
	{
		driver=new InternetExplorerDriver();
	}
	else {
		System.out.println("Invalid browser");
	}
	
	driver.get(URL);
	Thread.sleep(3000);
	}
	
	
	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
	
	@Test(dataProvider="loginTestData")
	
public void testLoginPage(String username,String password,String isTrue) 
	{
	driver.findElement(By.name("username")).sendKeys("username");
    driver.findElement(By.id("password")).sendKeys("password");
    driver.findElement(By.id("submit")).click();
	
	String actualtitle=driver.getTitle();
	String expectedtitle="Test Login | Practice Test Automation";
	

	if(isTrue.equalsIgnoreCase("1")) {
	
	Assert.assertEquals(actualtitle,expectedtitle,"test case failed due to title mismatch");

}
	else if(isTrue.equals("2"))
{
		WebElement invalidErrorElement=driver.findElement(By.xpath("//*[@id=\"error\"]"));
	Assert.assertTrue(invalidErrorElement.getText().equals("Your username is invalid!"));
}
	
	}	
	@DataProvider(name="loginTestData")
	public String[][] testData() {
		String data[][]=new String[3][3];
		
		data[0][0]="student";
		data[0][1]="Password123";
		data[0][2]="1";
		
		data[1][0]="xyxvsh";
		data[1][1]="hdguokj";
		data[1][2]="2";
		
		data[2][0]="#$%*&";
		data[2][1]="%$#@*";
		data[2][2]="2";
		
		return data;
		
	}
}

