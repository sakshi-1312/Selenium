package march10;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class LoginPage {
@BeforeClass
	public void setUp() {
		System.out.println("Hii");
	}
	@AfterClass
	public void tearDown() {
		System.out.println("Hello");
	}
	@Test(priority=1)
	public void testValidData() {
		System.out.println("Good Morning !!");
	}
	@Test(priority=2)
	public void testInvalidData() {
		System.out.println("Good Evening !!");
	}
}
