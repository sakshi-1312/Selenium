package march10;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Login1 {
	WebDriver driver;
	
	@BeforeMethod
public void setUp() {
	driver=new ChromeDriver();
	driver.get("https://practicetestautomation.com/practice-test-login/");
	}
	
	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
	
	@Test(priority=1)
	public void testValidData() {

	    driver.findElement(By.name("username")).sendKeys("student");
	    driver.findElement(By.id("password")).sendKeys("Password123");
	    driver.findElement(By.id("submit")).click();
		
		String actualtitle=driver.getTitle();
		String expectedtitle="Logged In Successfully | Practice Test Automation";
		
		Assert.assertEquals(actualtitle,expectedtitle,"Test case failed due to title mismatch");
	}
	@Test(priority=2)
	public void testInvalidData() {
		driver.findElement(By.name("username")).sendKeys("student123");
	    driver.findElement(By.id("password")).sendKeys("Password123");
	    driver.findElement(By.id("submit")).click();
	    
	    String pagesource=driver.getPageSource();
	    boolean actual=pagesource.contains("Username is invalid");
	    
	    Assert.assertEquals(actual, false);
	}
	@Test(enabled=false)
	public void testSpecialSymbol() {
		driver.findElement(By.name("username")).sendKeys("#@&*");
	    driver.findElement(By.id("password")).sendKeys("&*%$#");
	    driver.findElement(By.id("submit")).click();
	    
	    String pagesource=driver.getPageSource();
	    boolean actual=pagesource.contains("invalid credentials");
	    
	    Assert.assertEquals(actual, true);
	}
	    public void testLogout() {
	    	WebElement btnLogout=driver.findElement(By.xpath("//*[@id=\"loop-container\"]/div/article/div[2]/div/div/div/a"));
	    	Assert.assertTrue(btnLogout.isDisplayed());
	    }
	}
	



