package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
	@FindBy(name="username") WebElement txtEmail;
	@FindBy(name="password") WebElement txtPassword;
	@FindBy(name="remember") WebElement checkRemember;
	@FindBy(name="submit") WebElement btnLogin;
	
	public LoginPage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	public void email(String em)
	{
		txtEmail.sendKeys(em);
	}
	
	public void password(String pass)
	{
		txtPassword.sendKeys(pass);
	}
	
	public void remember()
	{
		checkRemember.click();
	}
	
	public void login()
	{
		btnLogin.click();
	}

}
