package com.testCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pages.LoginPage;

public class LoginPageTest {
	
	WebDriver driver;
	LoginPage lp;
	
	@BeforeMethod
	public void setup() 
	{
		driver=new ChromeDriver();
		driver.get("https://javabykiran.in/other/CC/login");
		lp=new LoginPage(driver);
		
	}
	
	@AfterMethod
	public void tearDown()
	{
		driver.quit();
	}
	
	@Test
	public void testValid()
	{
		lp.email("sakshi@gmail.com");
		lp.password("sakshi1234");
		lp.remember();
		lp.login();
	}
	
	@Test
	public void testInvalid()
	{
		lp.email("gmail.com");
		lp.password("s@kshi1234");
		lp.remember();
		lp.login();
	}
	
	@Test
	public void testInValid()
	{
		lp.email("*%$#@");
		lp.password("&*%#$34");
		lp.remember();
		lp.login();
	}
	
	

	

}
