package march18;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class SelectDemo {
	@Test
	public void testSelectClass() {
		
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://demo.automationtesting.in/Register.html");
		
		driver.manage().window().maximize();
		
		WebElement drpdwn=driver.findElement(By.id("Skills"));
		Select sc=new Select(drpdwn);
		//sc.selectByIndex(4);
		sc.selectByValue("Email");
		//sc.selectByVisibleText("CSS");
		
		//List<WebElement> alloptions=sc.getOptions();
		
		//for(WebElement option:alloptions) {
		//	System.out.println(option.getText());
		//}
		
		WebElement selectedValue=sc.getFirstSelectedOption();
		System.out.println(selectedValue.getText());
		
		
	}

}
