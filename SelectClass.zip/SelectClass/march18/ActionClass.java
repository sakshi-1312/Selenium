package march18;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class ActionClass {
	@Test
	public void testAction() {
		
		WebDriver  driver=new ChromeDriver();
		//driver.get("https://demo.automationtesting.in/Register.html");
		//driver.get("https://www.google.com/");
		driver.get("https://demo.automationtesting.in/Static.html");
		driver.manage().window().maximize();
		
		
		Actions ac=new Actions(driver);
		
		//ac.scrollByAmount(0, 500).perform();
		
		//ac.scrollToElement(driver.findElement(By.xpath("//*[@id=\"submitbtn\"]")));
		
		//ac.contextClick().perform();
		
		//ac.moveToElement(driver.findElement(By.xpath("//*[@id=\"submitbtn\"]")));
		
		//driver.findElement(By.id("APjFqb")).sendKeys("Selenium WebDriver");
		//ac.sendKeys(Keys.ENTER).perform();
		
		//driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]")).sendKeys("welcome");
		
		//ac.keyDown(Keys.CONTROL).sendKeys("A").keyUp(Keys.CONTROL).perform();
		//ac.keyDown(Keys.CONTROL).sendKeys("C").keyUp(Keys.CONTROL).perform();
		
		//ac.keyDown(Keys.TAB).perform();
		
		//ac.keyDown(Keys.CONTROL).sendKeys("V").keyUp(Keys.CONTROL).perform();
		
		WebElement source1=driver.findElement(By.id("angular"));
		WebElement source2=driver.findElement(By.id("mongo"));
		
		WebElement destination=driver.findElement(By.id("droparea"));
		ac.dragAndDrop(source1, destination).perform();
		ac.dragAndDrop(source2, destination).perform();
	
	
	}

}
