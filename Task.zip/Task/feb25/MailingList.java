package feb25;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MailingList {
	
	public void MailingListTest() throws InterruptedException{
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://javabykiran.in/other/CC/search");
		
		WebElement enteredEmail=driver.findElement(By.xpath("//*[@id=\"newsletter_email\"]"));
		enteredEmail.sendKeys("abc123@gmail.com");
		
		WebElement subscribeButton=driver.findElement(By.xpath("//*[@id=\"subscribe_button\"]"));
		subscribeButton.click();
		
		Thread.sleep(4000);
		WebElement successMessage=driver.findElement(By.cssSelector("#main_content > div.alert-box.success > ul > li"));
		String ActualMessage=successMessage.getText();
		
		if(ActualMessage.equals("Your email address has been added to our mailing list.")) 
		{

			System.out.println("Test case Pass");
		}
		else 
		{
			System.out.println("Test case Fail");
		}
		
		driver.close();
	}

}
