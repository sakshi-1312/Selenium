package feb25;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class InvalidProductList {
	

	public void testInvalidProduct() {
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://javabykiran.in/other/CC/");

		WebElement searchBox=driver.findElement(By.name("search[keywords]"));
		searchBox.sendKeys("1234abc");
		
		WebElement searchButton=driver.findElement(By.xpath("//*[@id=\"top_header\"]/div[2]/div[2]/div/div/form/div/div[2]/button"));
		searchButton.click();
		
	    String pageSource=driver.getPageSource();
		if(pageSource.contains("No products found")) 
		{
			System.out.println("Test case Pass");
		}
		else
		{
			System.out.println("Test case Failed");
		}
		
		driver.close();
}
}
