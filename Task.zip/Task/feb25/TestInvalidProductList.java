package feb25;

public class TestInvalidProductList {

	public static void main(String[] args){
		
		InvalidProductList ip=new InvalidProductList();
		ip.testInvalidProduct();
	}

}
