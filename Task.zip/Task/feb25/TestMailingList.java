package feb25;

public class TestMailingList {
	
	public static void main(String[] args) throws InterruptedException {

		MailingList ml = new MailingList();
		ml.MailingListTest();
	}
}
